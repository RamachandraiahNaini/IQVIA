﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using IQVIA_Tweet_App.Models;
using System.Net.Http;
using Newtonsoft.Json;
using System.Configuration;

namespace IQVIA_Tweet_App.Controllers
{
    public class TweetController : Controller
    {
        string startDate = ConfigurationManager.AppSettings["startDate"];
        string endDate = ConfigurationManager.AppSettings["endDate"];
        int year = Convert.ToInt32(ConfigurationManager.AppSettings["year"]);
        int lastIteration = Convert.ToInt32(ConfigurationManager.AppSettings["lastIteration"]);
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Summery()
        {
            var totalTweets = GetTweets(startDate, endDate).ToList();
            var uniqueTweets = totalTweets.GroupBy(x => x.Text).Select(x => x.First()).ToList();
            Tweets model = new Tweets()
            {
                TotalTweets = totalTweets.Count(),
                TotalUniqueTweets = uniqueTweets.Count(),
            };
            return View("~/Views/Tweet/About.cshtml", model);
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "My Details";
            return View();
        }
        public ActionResult GetTweets()
        {
            var totalTweets = GetTweets(startDate, endDate).ToList();
            var uniqueTweets = totalTweets.GroupBy(x => x.Text).Select(x => x.First()).ToList();
            Tweets model = new Tweets()
            {
                TweetList=uniqueTweets
            };
            return View(model);
        }

        private IEnumerable<Tweet> GetTweets(string startDate, string endDate)
        {
            using (HttpClient client = new HttpClient() { BaseAddress = new Uri(ConfigurationManager.AppSettings["tweetBadAPI"]) })
            {
                List<Tweet> buffer = default(List<Tweet>);
                for (; buffer==null? true:buffer.Count>=100; startDate = Convert.ToDateTime(buffer.Last().Stamp).ToUniversalTime().ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'"))
                {
                    HttpResponseMessage response = client.GetAsync("?startDate=" + startDate + "&endDate=" + endDate).Result;
                    if (!response.IsSuccessStatusCode)
                        break;

                    buffer = JsonConvert.DeserializeObject<List<Tweet>>(response.Content.ReadAsStringAsync().Result).Where(x=>Convert.ToDateTime(x.Stamp).Year>= year).OrderBy(x => x.Stamp).ToList();
                    if (buffer.Count==0)
                        break;
                    foreach (Tweet twt in buffer.Take(buffer.Count==100? buffer.Count -1: buffer.Count))
                        yield return twt;
                }
                if(buffer.Count== lastIteration)
                    yield return buffer.Last();
            }
        }
        
    }

    

}