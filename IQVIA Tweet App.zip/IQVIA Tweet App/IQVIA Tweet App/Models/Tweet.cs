﻿using System;
using System.ComponentModel;

namespace IQVIA_Tweet_App.Models
{
    public class Tweet
    {
        [DisplayName("Tweet ID")]
        public long Id { get; set; }
        [DisplayName("Tweet Time Stamp")]
        public string Stamp { get; set; }

        [DisplayName("Tweet Text")]
        public string Text { get; set; }
    }
}