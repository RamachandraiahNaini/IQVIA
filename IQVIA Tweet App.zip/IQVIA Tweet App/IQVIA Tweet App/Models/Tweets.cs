﻿using System;
using System.Collections.Generic;
using System.Collections;

namespace IQVIA_Tweet_App.Models
{
    public class Tweets
    {
        public long TotalTweets = 0;
        public long TotalUniqueTweets = 0;
        public long TotalDuplicateTweets
        {
            get
            {
                return TotalTweets- TotalUniqueTweets;
            }
        }
        public List<Tweet> TweetList = new List<Tweet>();
    }
}