﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using IQVIA_Tweet_App.Models;
using System.Net.Http;
using Newtonsoft.Json;
using System.Configuration;
using IQVIA_Tweet_App.Loger;

namespace IQVIA_Tweet_App.Controllers
{
    public class TweetController : Controller
    {
        string startDate = ConfigurationManager.AppSettings["startDate"];
        string endDate = ConfigurationManager.AppSettings["endDate"];
        int year = Convert.ToInt32(ConfigurationManager.AppSettings["year"]);
        int lastIteration = Convert.ToInt32(ConfigurationManager.AppSettings["lastIteration"]);

        public ActionResult Index()
        {
            AppLogManager.Info("Enters Index method in TweetController ");
            return View();
        }

        public ActionResult Summery()
        {
            AppLogManager.Info("Enters Summery method in TweetController ");

            var totalTweets = GetTweets(startDate, endDate).ToList();
            var uniqueTweets = totalTweets.GroupBy(x => x.Text).Select(x => x.First()).ToList();
            Tweets model = new Tweets()
            {
                TotalTweets = totalTweets.Count(),
                TotalUniqueTweets = uniqueTweets.Count(),
            };
            AppLogManager.Info("Ended Summery method in TweetController ");
            return View("~/Views/Tweet/About.cshtml", model);
        }

        public ActionResult Contact()
        {
            AppLogManager.Info("Enters Contact method in TweetController ");
            ViewBag.Message = "My Details";
            return View();
        }
        public ActionResult GetTweets()
        {
            AppLogManager.Info("Enters GetTweets method in TweetController ");
            var totalTweets = GetTweets(startDate, endDate).ToList();
            var uniqueTweets = totalTweets.GroupBy(x => x.Text).Select(x => x.First()).ToList();
            Tweets model = new Tweets()
            {
                TweetList=uniqueTweets
            };
            AppLogManager.Info("Ended GetTweets method in TweetController ");
            return View(model);
        }

        private IEnumerable<Tweet> GetTweets(string startDate, string endDate)
        {
            AppLogManager.Info("Enters GetTweets method in TweetController startDate : "+ startDate + "  endDate : "+ endDate);
            using (HttpClient client = new HttpClient() { BaseAddress = new Uri(ConfigurationManager.AppSettings["tweetBadAPI"]) })
            {
                List<Tweet> buffer = default(List<Tweet>);
                for (; buffer==null? true:buffer.Count>=100; startDate = Convert.ToDateTime(buffer.Last().Stamp).ToUniversalTime().ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'"))
                {
                    AppLogManager.Info("Inside GetTweets method loop  startDate : " + startDate + "  endDate : " + endDate);
                    try
                    {
                        HttpResponseMessage response = client.GetAsync("?startDate=" + startDate + "&endDate=" + endDate).Result;
                        if (!response.IsSuccessStatusCode)
                            break;

                        buffer = JsonConvert.DeserializeObject<List<Tweet>>(response.Content.ReadAsStringAsync().Result).Where(x => Convert.ToDateTime(x.Stamp).Year >= year).OrderBy(x => x.Stamp).ToList();
                    }
                    catch(Exception  ex)
                    {
                        AppLogManager.Error(ex.Message);
                    }
                    if (buffer.Count==0)
                        break;
                    foreach (Tweet twt in buffer.Take(buffer.Count==100? buffer.Count -1: buffer.Count))
                        yield return twt;
                }
                if(buffer.Count== lastIteration)
                    yield return buffer.Last();
            }
            AppLogManager.Info("Ended GetTweets method in TweetController startDate : " + startDate + "  endDate : " + endDate);
        }
        
    }

    

}