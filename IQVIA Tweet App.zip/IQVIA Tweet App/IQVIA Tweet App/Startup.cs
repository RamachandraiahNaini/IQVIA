﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(IQVIA_Tweet_App.Startup))]
namespace IQVIA_Tweet_App
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
